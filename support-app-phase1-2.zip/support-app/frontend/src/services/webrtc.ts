/**
 * Phase 2 uses a public STUN server only, which is enough on most local/
 * demo networks. In production, add a TURN server below (required for
 * clients behind symmetric NAT / restrictive firewalls) — the shape is
 * ready for it, nothing else in the app needs to change.
 */
export const ICE_SERVERS: RTCIceServer[] = [
  { urls: "stun:stun.l.google.com:19302" },
  // { urls: "turn:your-turn-server.example.com:3478", username: "user", credential: "pass" },
];

export function createPeerConnection(): RTCPeerConnection {
  return new RTCPeerConnection({ iceServers: ICE_SERVERS });
}
