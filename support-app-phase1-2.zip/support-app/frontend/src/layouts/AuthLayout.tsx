import { Outlet, Navigate } from "react-router-dom";
import { useAuth } from "../hooks/useAuth";

export function AuthLayout() {
  const { user, loading } = useAuth();

  if (loading) return null;
  if (user) return <Navigate to="/dashboard" replace />;

  return (
    <div className="flex min-h-screen items-center justify-center bg-gray-50 dark:bg-gray-950">
      <div className="w-full max-w-sm rounded-2xl border border-gray-200 bg-white p-8 shadow-sm dark:border-gray-800 dark:bg-gray-900">
        <div className="mb-6 text-center text-xl font-semibold text-brand-600 dark:text-brand-500">
          RemoteSupport
        </div>
        <Outlet />
      </div>
    </div>
  );
}
