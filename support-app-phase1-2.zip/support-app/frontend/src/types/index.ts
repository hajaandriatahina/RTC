export interface User {
  id: string;
  email: string;
  name: string;
}

export type DeviceStatus = "ONLINE" | "OFFLINE";

export interface Device {
  id: string;
  deviceId: string;
  name: string;
  status: DeviceStatus;
  lastSeenAt: string | null;
  ownerId: string;
  createdAt: string;
  updatedAt: string;
}

export interface AuthResponse {
  token: string;
  user: User;
}

export type SessionStatus = "PENDING" | "ACTIVE" | "DENIED" | "ENDED" | "EXPIRED";

export interface SessionRecord {
  id: string;
  status: SessionStatus;
  controlGranted: boolean;
  requestedAt: string;
  acceptedAt: string | null;
  endedAt: string | null;
  endReason: string | null;
  device: Device;
}
