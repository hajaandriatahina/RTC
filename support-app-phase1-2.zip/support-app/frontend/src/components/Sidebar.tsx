import { NavLink } from "react-router-dom";

const links = [
  { to: "/dashboard", label: "Tableau de bord" },
  { to: "/devices", label: "Appareils" },
  { to: "/sessions", label: "Sessions" },
  { to: "/settings", label: "Paramètres" },
];

export function Sidebar() {
  return (
    <aside className="hidden md:flex w-56 shrink-0 flex-col border-r border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
      <div className="flex h-14 items-center px-5 font-semibold text-brand-600 dark:text-brand-500">
        RemoteSupport
      </div>
      <nav className="flex-1 space-y-1 px-3 py-2">
        {links.map((link) => (
          <NavLink
            key={link.to}
            to={link.to}
            className={({ isActive }) =>
              `block rounded-lg px-3 py-2 text-sm font-medium transition-colors ${
                isActive
                  ? "bg-brand-50 text-brand-700 dark:bg-brand-700/20 dark:text-brand-500"
                  : "text-gray-600 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-800"
              }`
            }
          >
            {link.label}
          </NavLink>
        ))}
      </nav>
    </aside>
  );
}
