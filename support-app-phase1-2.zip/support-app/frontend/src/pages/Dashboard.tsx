import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../services/api";
import { Device } from "../types";

function Card({ label, value }: { label: string; value: number | string }) {
  return (
    <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-gray-900">
      <div className="text-sm text-gray-500 dark:text-gray-400">{label}</div>
      <div className="mt-1 text-3xl font-semibold">{value}</div>
    </div>
  );
}

export function Dashboard() {
  const [devices, setDevices] = useState<Device[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api
      .get<Device[]>("/devices")
      .then((res) => setDevices(res.data))
      .finally(() => setLoading(false));
  }, []);

  const online = devices.filter((d) => d.status === "ONLINE").length;
  const offline = devices.length - online;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Tableau de bord</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400">
          Vue d'ensemble de vos appareils et sessions.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
        <Card label="Appareils connectés" value={loading ? "…" : devices.length} />
        <Card label="Disponibles" value={loading ? "…" : online} />
        <Card label="Hors ligne" value={loading ? "…" : offline} />
        <Card label="Sessions actives" value={0} />
      </div>

      <div className="rounded-2xl border border-gray-200 bg-white p-5 dark:border-gray-800 dark:bg-gray-900">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-medium">Appareils récents</h2>
          <Link
            to="/devices"
            className="rounded-lg bg-brand-600 px-4 py-2 text-sm font-medium text-white hover:bg-brand-700"
          >
            Connecter
          </Link>
        </div>
        {devices.length === 0 && !loading && (
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Aucun appareil enregistré pour le moment.
          </p>
        )}
        <ul className="divide-y divide-gray-100 dark:divide-gray-800">
          {devices.slice(0, 5).map((d) => (
            <li key={d.id} className="flex items-center justify-between py-3 text-sm">
              <span>{d.name}</span>
              <span className="text-gray-400">{d.deviceId}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
