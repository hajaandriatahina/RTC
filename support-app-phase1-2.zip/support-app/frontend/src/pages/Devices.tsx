import { useEffect, useState, FormEvent } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../services/api";
import { getSocket } from "../services/socket";
import { Device } from "../types";
import { StatusBadge } from "../components/StatusBadge";

export function Devices() {
  const navigate = useNavigate();
  const [devices, setDevices] = useState<Device[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [showConnectModal, setShowConnectModal] = useState(false);
  const [newDeviceName, setNewDeviceName] = useState("");
  const [connectDeviceId, setConnectDeviceId] = useState("");
  const [error, setError] = useState<string | null>(null);

  function loadDevices() {
    setLoading(true);
    api
      .get<Device[]>("/devices")
      .then((res) => setDevices(res.data))
      .finally(() => setLoading(false));
  }

  useEffect(() => {
    loadDevices();

    // Live status updates: when an Agent connects/disconnects, the backend
    // broadcasts device:status over the same socket used for auth.
    const socket = getSocket();
    function onStatus(payload: { deviceId: string; status: "ONLINE" | "OFFLINE" }) {
      setDevices((prev) =>
        prev.map((d) => (d.deviceId === payload.deviceId ? { ...d, status: payload.status } : d))
      );
    }
    socket.on("device:status", onStatus);
    return () => {
      socket.off("device:status", onStatus);
    };
  }, []);

  async function handleAddDevice(e: FormEvent) {
    e.preventDefault();
    setError(null);
    try {
      await api.post("/devices", { name: newDeviceName });
      setNewDeviceName("");
      setShowAddModal(false);
      loadDevices();
    } catch (err: any) {
      setError(err?.response?.data?.error || "Échec de l'enregistrement de l'appareil");
    }
  }

  function handleConnect(e: FormEvent) {
    e.preventDefault();
    // A device is looked up by its Device ID, then routed to its detail
    // page where the actual connection request/pairing-code flow happens.
    const target = devices.find((d) => d.deviceId === connectDeviceId.trim().toUpperCase());
    if (target) {
      navigate(`/devices/${target.id}`);
    } else {
      setError("Device ID introuvable parmi vos appareils.");
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Appareils</h1>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Gérez les appareils enregistrés et lancez une connexion.
          </p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setShowConnectModal(true)}
            className="rounded-lg bg-brand-600 px-4 py-2 text-sm font-medium text-white hover:bg-brand-700"
          >
            Connecter
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="rounded-lg border border-gray-300 px-4 py-2 text-sm font-medium hover:bg-gray-50 dark:border-gray-700 dark:hover:bg-gray-800"
          >
            + Nouvel appareil
          </button>
        </div>
      </div>

      <div className="overflow-hidden rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-gray-100 text-gray-500 dark:border-gray-800 dark:text-gray-400">
            <tr>
              <th className="px-5 py-3 font-medium">Nom</th>
              <th className="px-5 py-3 font-medium">Device ID</th>
              <th className="px-5 py-3 font-medium">Statut</th>
              <th className="px-5 py-3 font-medium">Dernière connexion</th>
              <th className="px-5 py-3" />
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
            {devices.map((d) => (
              <tr key={d.id}>
                <td className="px-5 py-3">{d.name}</td>
                <td className="px-5 py-3 font-mono text-xs text-gray-500">{d.deviceId}</td>
                <td className="px-5 py-3">
                  <StatusBadge status={d.status} />
                </td>
                <td className="px-5 py-3 text-gray-500">
                  {d.lastSeenAt ? new Date(d.lastSeenAt).toLocaleString("fr-FR") : "—"}
                </td>
                <td className="px-5 py-3 text-right">
                  <button
                    onClick={() => navigate(`/devices/${d.id}`)}
                    className="text-brand-600 hover:underline"
                  >
                    Ouvrir
                  </button>
                </td>
              </tr>
            ))}
            {devices.length === 0 && !loading && (
              <tr>
                <td colSpan={5} className="px-5 py-8 text-center text-gray-400">
                  Aucun appareil enregistré.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {showAddModal && (
        <Modal onClose={() => setShowAddModal(false)} title="Nouvel appareil">
          <form onSubmit={handleAddDevice} className="space-y-4">
            {error && <p className="text-sm text-red-600">{error}</p>}
            <div>
              <label className="mb-1 block text-sm font-medium">Nom de l'appareil</label>
              <input
                required
                value={newDeviceName}
                onChange={(e) => setNewDeviceName(e.target.value)}
                placeholder="ex : PC Support Client A"
                className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm dark:border-gray-700 dark:bg-gray-800"
              />
            </div>
            <button
              type="submit"
              className="w-full rounded-lg bg-brand-600 py-2 text-sm font-medium text-white hover:bg-brand-700"
            >
              Enregistrer
            </button>
          </form>
        </Modal>
      )}

      {showConnectModal && (
        <Modal onClose={() => setShowConnectModal(false)} title="Se connecter à un appareil">
          <form onSubmit={handleConnect} className="space-y-4">
            {error && <p className="text-sm text-red-600">{error}</p>}
            <div>
              <label className="mb-1 block text-sm font-medium">Device ID</label>
              <input
                required
                value={connectDeviceId}
                onChange={(e) => setConnectDeviceId(e.target.value)}
                placeholder="ex : XJ3K-9QZP"
                className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm font-mono dark:border-gray-700 dark:bg-gray-800"
              />
            </div>
            <button
              type="submit"
              className="w-full rounded-lg bg-brand-600 py-2 text-sm font-medium text-white hover:bg-brand-700"
            >
              Continuer
            </button>
          </form>
        </Modal>
      )}
    </div>
  );
}

function Modal({
  title,
  onClose,
  children,
}: {
  title: string;
  onClose: () => void;
  children: React.ReactNode;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <div className="w-full max-w-sm rounded-2xl bg-white p-6 dark:bg-gray-900">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="font-medium">{title}</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
          >
            ✕
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}
