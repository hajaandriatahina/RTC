import { useEffect, useRef, useState, useCallback } from "react";
import { useParams } from "react-router-dom";
import { api } from "../services/api";
import { getSocket } from "../services/socket";
import { createPeerConnection } from "../services/webrtc";
import { Device } from "../types";
import { StatusBadge } from "../components/StatusBadge";

type CallState = "idle" | "requesting" | "pending" | "active" | "denied" | "ended" | "error";

const stateLabel: Record<CallState, string> = {
  idle: "",
  requesting: "Envoi de la demande…",
  pending: "En attente d'acceptation par l'appareil…",
  active: "Connecté",
  denied: "Demande refusée par le propriétaire de l'appareil",
  ended: "Session terminée",
  error: "Erreur",
};

export function DeviceDetail() {
  const { id } = useParams<{ id: string }>();
  const [device, setDevice] = useState<Device | null>(null);
  const [pairingCode, setPairingCode] = useState<string | null>(null);
  const [pairingError, setPairingError] = useState<string | null>(null);
  const [requestingPairing, setRequestingPairing] = useState(false);

  const [callState, setCallState] = useState<CallState>("idle");
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [rttMs, setRttMs] = useState<number | null>(null);

  const sessionIdRef = useRef<string | null>(null);
  const pcRef = useRef<RTCPeerConnection | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const statsIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (!id) return;
    api.get<Device>(`/devices/${id}`).then((res) => setDevice(res.data));
  }, [id]);

  const cleanupCall = useCallback(() => {
    pcRef.current?.close();
    pcRef.current = null;
    sessionIdRef.current = null;
    if (videoRef.current) videoRef.current.srcObject = null;
    if (statsIntervalRef.current) {
      clearInterval(statsIntervalRef.current);
      statsIntervalRef.current = null;
    }
    setRttMs(null);
  }, []);

  // --- Socket listeners for the session + WebRTC signaling lifecycle -----
  useEffect(() => {
    const socket = getSocket();

    function onSessionPending(payload: { sessionId: string }) {
      sessionIdRef.current = payload.sessionId;
      setCallState("pending");
    }

    async function onSessionResponse(payload: { sessionId: string; accepted: boolean }) {
      if (payload.sessionId !== sessionIdRef.current) return;
      if (!payload.accepted) {
        setCallState("denied");
        sessionIdRef.current = null;
        return;
      }

      setCallState("active");
      await startOfferAsTechnician(payload.sessionId);
    }

    async function onWebrtcAnswer(payload: { sessionId: string; sdp: RTCSessionDescriptionInit }) {
      if (payload.sessionId !== sessionIdRef.current || !pcRef.current) return;
      await pcRef.current.setRemoteDescription(payload.sdp);
    }

    async function onIceCandidate(payload: { sessionId: string; candidate: RTCIceCandidateInit }) {
      if (payload.sessionId !== sessionIdRef.current || !pcRef.current) return;
      try {
        await pcRef.current.addIceCandidate(payload.candidate);
      } catch {
        // benign if it arrives before remote description is set in rare races
      }
    }

    function onSessionEnded() {
      cleanupCall();
      setCallState("ended");
    }

    function onSessionError(payload: { message: string }) {
      setErrorMessage(payload.message);
      setCallState("error");
    }

    socket.on("session:pending", onSessionPending);
    socket.on("session:response", onSessionResponse);
    socket.on("webrtc:answer", onWebrtcAnswer);
    socket.on("webrtc:ice-candidate", onIceCandidate);
    socket.on("session:ended", onSessionEnded);
    socket.on("session:error", onSessionError);

    return () => {
      socket.off("session:pending", onSessionPending);
      socket.off("session:response", onSessionResponse);
      socket.off("webrtc:answer", onWebrtcAnswer);
      socket.off("webrtc:ice-candidate", onIceCandidate);
      socket.off("session:ended", onSessionEnded);
      socket.off("session:error", onSessionError);
      cleanupCall();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function startOfferAsTechnician(sessionId: string) {
    const socket = getSocket();
    const pc = createPeerConnection();
    pcRef.current = pc;

    pc.ontrack = (event) => {
      if (videoRef.current) videoRef.current.srcObject = event.streams[0];
    };

    pc.onicecandidate = (event) => {
      if (event.candidate) {
        socket.emit("webrtc:ice-candidate", { sessionId, candidate: event.candidate });
      }
    };

    // Technician is a viewer only in Phase 2 — no local media is sent.
    pc.addTransceiver("video", { direction: "recvonly" });

    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    socket.emit("webrtc:offer", { sessionId, sdp: offer });

    statsIntervalRef.current = setInterval(async () => {
      const stats = await pc.getStats();
      stats.forEach((report) => {
        if (report.type === "candidate-pair" && report.state === "succeeded" && report.currentRoundTripTime != null) {
          setRttMs(Math.round(report.currentRoundTripTime * 1000));
        }
      });
    }, 2000);
  }

  function handleRequestConnection() {
    if (!device) return;
    setErrorMessage(null);
    setCallState("requesting");
    getSocket().emit("session:request", { deviceId: device.deviceId });
  }

  function handleDisconnect() {
    const sessionId = sessionIdRef.current;
    if (sessionId) {
      getSocket().emit("session:end", { sessionId, reason: "technician_disconnected" });
    }
    cleanupCall();
    setCallState("idle");
  }

  async function handleRefresh() {
    const sessionId = sessionIdRef.current;
    const pc = pcRef.current;
    if (!sessionId || !pc) return;
    const offer = await pc.createOffer({ iceRestart: true });
    await pc.setLocalDescription(offer);
    getSocket().emit("webrtc:offer", { sessionId, sdp: offer });
  }

  function handleFullscreen() {
    videoRef.current?.requestFullscreen?.();
  }

  function handleRequestControl() {
    const sessionId = sessionIdRef.current;
    if (sessionId) getSocket().emit("control:request", { sessionId });
  }

  async function handleRequestPairingCode() {
    if (!id) return;
    setPairingError(null);
    setRequestingPairing(true);
    try {
      const { data } = await api.post(`/devices/${id}/pairing-code`);
      setPairingCode(data.code);
    } catch (err: any) {
      setPairingError(err?.response?.data?.error || "Échec de la demande de code");
    } finally {
      setRequestingPairing(false);
    }
  }

  if (!device) return <p className="text-sm text-gray-500">Chargement…</p>;

  const isCallLive = callState === "requesting" || callState === "pending" || callState === "active";

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold">{device.name}</h1>
          <p className="font-mono text-sm text-gray-500">{device.deviceId}</p>
        </div>
        <StatusBadge status={device.status} />
      </div>

      {/* Remote screen viewer */}
      <div className="overflow-hidden rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
        <div className="relative flex aspect-video items-center justify-center bg-gray-900">
          <video ref={videoRef} autoPlay playsInline className="h-full w-full object-contain" />
          {callState !== "active" && (
            <div className="absolute inset-0 flex items-center justify-center text-sm text-gray-400">
              {callState === "idle"
                ? "Aucune session en cours."
                : stateLabel[callState] + (errorMessage ? ` — ${errorMessage}` : "")}
            </div>
          )}
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-gray-100 px-5 py-3 dark:border-gray-800">
          <div className="text-sm text-gray-500 dark:text-gray-400">
            {callState === "active" ? (
              <>
                Statut : <span className="font-medium text-emerald-600">Connecté</span>
                {rttMs !== null && <> · Latence : {rttMs} ms</>}
              </>
            ) : (
              stateLabel[callState] || "Prêt à se connecter"
            )}
          </div>
          <div className="flex flex-wrap gap-2">
            {!isCallLive && callState !== "active" ? (
              <button
                onClick={handleRequestConnection}
                disabled={device.status !== "ONLINE"}
                className="rounded-lg bg-brand-600 px-4 py-2 text-sm font-medium text-white hover:bg-brand-700 disabled:opacity-50"
              >
                Demander une connexion
              </button>
            ) : (
              <>
                <button
                  onClick={handleRequestControl}
                  disabled={callState !== "active"}
                  title="Disponible une fois les permissions Android accordées (Phase 4)"
                  className="rounded-lg border border-gray-300 px-4 py-2 text-sm font-medium hover:bg-gray-50 disabled:opacity-50 dark:border-gray-700 dark:hover:bg-gray-800"
                >
                  Request control
                </button>
                <button
                  onClick={handleFullscreen}
                  disabled={callState !== "active"}
                  className="rounded-lg border border-gray-300 px-4 py-2 text-sm font-medium hover:bg-gray-50 disabled:opacity-50 dark:border-gray-700 dark:hover:bg-gray-800"
                >
                  Full screen
                </button>
                <button
                  onClick={handleRefresh}
                  disabled={callState !== "active"}
                  className="rounded-lg border border-gray-300 px-4 py-2 text-sm font-medium hover:bg-gray-50 disabled:opacity-50 dark:border-gray-700 dark:hover:bg-gray-800"
                >
                  Refresh
                </button>
                <button
                  onClick={handleDisconnect}
                  className="rounded-lg bg-red-600 px-4 py-2 text-sm font-medium text-white hover:bg-red-700"
                >
                  Disconnect
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {device.status !== "ONLINE" && (
        <p className="text-sm text-amber-600 dark:text-amber-400">
          L'appareil est actuellement hors ligne — une session ne peut pas être demandée.
        </p>
      )}

      {/* Optional extra pairing-code layer, independent of the accept/deny flow above */}
      <div className="rounded-2xl border border-gray-200 bg-white p-6 dark:border-gray-800 dark:bg-gray-900">
        <h2 className="mb-2 font-medium">Code de vérification (optionnel)</h2>
        <p className="mb-4 text-sm text-gray-500 dark:text-gray-400">
          Génère un code à 6 chiffres à communiquer oralement au propriétaire
          de l'appareil, en plus de l'acceptation explicite affichée sur son
          appareil.
        </p>
        {pairingError && <p className="mb-3 text-sm text-red-600">{pairingError}</p>}
        <button
          onClick={handleRequestPairingCode}
          disabled={requestingPairing || device.status !== "ONLINE"}
          className="rounded-lg border border-gray-300 px-4 py-2 text-sm font-medium hover:bg-gray-50 disabled:opacity-50 dark:border-gray-700 dark:hover:bg-gray-800"
        >
          {requestingPairing ? "Génération…" : "Générer un code"}
        </button>
        {pairingCode && (
          <div className="mt-4 rounded-lg bg-brand-50 px-4 py-3 text-sm dark:bg-brand-700/10">
            Code : <span className="font-mono text-base font-semibold">{pairingCode}</span>
          </div>
        )}
      </div>
    </div>
  );
}
