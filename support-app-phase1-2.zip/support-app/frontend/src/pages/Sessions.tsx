import { useEffect, useState } from "react";
import { api } from "../services/api";
import { SessionRecord } from "../types";

const statusLabel: Record<string, string> = {
  PENDING: "En attente",
  ACTIVE: "Active",
  DENIED: "Refusée",
  ENDED: "Terminée",
  EXPIRED: "Expirée",
};

const statusColor: Record<string, string> = {
  PENDING: "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300",
  ACTIVE: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300",
  DENIED: "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300",
  ENDED: "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400",
  EXPIRED: "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400",
};

export function Sessions() {
  const [sessions, setSessions] = useState<SessionRecord[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api
      .get<SessionRecord[]>("/sessions")
      .then((res) => setSessions(res.data))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">Sessions</h1>
        <p className="text-sm text-gray-500 dark:text-gray-400">
          Historique et sessions actives.
        </p>
      </div>

      <div className="overflow-hidden rounded-2xl border border-gray-200 bg-white dark:border-gray-800 dark:bg-gray-900">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-gray-100 text-gray-500 dark:border-gray-800 dark:text-gray-400">
            <tr>
              <th className="px-5 py-3 font-medium">Appareil</th>
              <th className="px-5 py-3 font-medium">Statut</th>
              <th className="px-5 py-3 font-medium">Demandée le</th>
              <th className="px-5 py-3 font-medium">Terminée le</th>
              <th className="px-5 py-3 font-medium">Motif de fin</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
            {sessions.map((s) => (
              <tr key={s.id}>
                <td className="px-5 py-3">{s.device.name}</td>
                <td className="px-5 py-3">
                  <span
                    className={`rounded-full px-2.5 py-0.5 text-xs font-medium ${statusColor[s.status]}`}
                  >
                    {statusLabel[s.status]}
                  </span>
                </td>
                <td className="px-5 py-3 text-gray-500">
                  {new Date(s.requestedAt).toLocaleString("fr-FR")}
                </td>
                <td className="px-5 py-3 text-gray-500">
                  {s.endedAt ? new Date(s.endedAt).toLocaleString("fr-FR") : "—"}
                </td>
                <td className="px-5 py-3 text-gray-500">{s.endReason || "—"}</td>
              </tr>
            ))}
            {sessions.length === 0 && !loading && (
              <tr>
                <td colSpan={5} className="px-5 py-8 text-center text-gray-400">
                  Aucune session pour le moment.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
