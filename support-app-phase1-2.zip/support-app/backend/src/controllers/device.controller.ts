import { Response, NextFunction } from "express";
import { z } from "zod";
import { AuthenticatedRequest } from "../middleware/auth.middleware";
import {
  registerDevice,
  listDevicesForUser,
  getDeviceById,
  createPairingCode,
} from "../services/device.service";

const registerDeviceSchema = z.object({
  name: z.string().min(1),
});

export async function createDevice(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  try {
    const { name } = registerDeviceSchema.parse(req.body);
    const device = await registerDevice(req.user!.userId, name);
    res.status(201).json(device);
  } catch (err) {
    next(err);
  }
}

export async function listDevices(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  try {
    const devices = await listDevicesForUser(req.user!.userId);
    res.status(200).json(devices);
  } catch (err) {
    next(err);
  }
}

export async function getDevice(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  try {
    const device = await getDeviceById(req.params.id, req.user!.userId);
    res.status(200).json(device);
  } catch (err) {
    next(err);
  }
}

export async function requestPairingCode(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  try {
    // Verifies the device belongs to the requesting user before issuing a code.
    const device = await getDeviceById(req.params.id, req.user!.userId);
    const pairing = await createPairingCode(device.deviceId);
    res.status(201).json({ code: pairing.code, expiresAt: pairing.expiresAt });
  } catch (err) {
    next(err);
  }
}
