import { Response, NextFunction } from "express";
import { AuthenticatedRequest } from "../middleware/auth.middleware";
import { listSessionsForUser } from "../services/session.service";

export async function listSessions(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  try {
    const sessions = await listSessionsForUser(req.user!.userId);
    res.status(200).json(sessions);
  } catch (err) {
    next(err);
  }
}
