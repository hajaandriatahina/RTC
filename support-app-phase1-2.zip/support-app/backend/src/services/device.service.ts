import { v4 as uuidv4 } from "uuid";
import { prisma } from "../utils/prisma";
import { AppError } from "../middleware/errorHandler";
import { env } from "../config/env";

/**
 * Generates the human-shareable Device ID shown on the Agent screen, e.g.
 * "XJ3K-9QZP". Not a secret by itself — the pairing code is what actually
 * authorizes a connection.
 */
function generateDeviceId(): string {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // no ambiguous chars
  const block = () =>
    Array.from({ length: 4 }, () => chars[Math.floor(Math.random() * chars.length)]).join("");
  return `${block()}-${block()}`;
}

function generatePairingCode(): string {
  return Math.floor(100000 + Math.random() * 900000).toString(); // 6 digits
}

export async function registerDevice(ownerId: string, name: string) {
  let deviceId = generateDeviceId();
  // Extremely unlikely collision, but guard anyway.
  // eslint-disable-next-line no-constant-condition
  while (await prisma.device.findUnique({ where: { deviceId } })) {
    deviceId = generateDeviceId();
  }

  const device = await prisma.device.create({
    data: {
      id: uuidv4(),
      deviceId,
      name,
      ownerId,
      status: "OFFLINE",
    },
  });
  return device;
}

export async function listDevicesForUser(ownerId: string) {
  return prisma.device.findMany({
    where: { ownerId },
    orderBy: { createdAt: "desc" },
  });
}

export async function getDeviceById(id: string, ownerId: string) {
  const device = await prisma.device.findFirst({ where: { id, ownerId } });
  if (!device) throw new AppError("Device not found", 404);
  return device;
}

export async function setDeviceStatus(deviceId: string, status: "ONLINE" | "OFFLINE") {
  return prisma.device.update({
    where: { deviceId },
    data: { status, lastSeenAt: new Date() },
  });
}

export async function createPairingCode(deviceId: string) {
  const device = await prisma.device.findUnique({ where: { deviceId } });
  if (!device) throw new AppError("Device not found", 404);

  const code = generatePairingCode();
  const expiresAt = new Date(Date.now() + env.pairingCodeTtlSeconds * 1000);

  const pairing = await prisma.pairingCode.create({
    data: { code, deviceId: device.id, expiresAt },
  });
  return pairing;
}

export async function verifyPairingCode(deviceId: string, code: string) {
  const device = await prisma.device.findUnique({ where: { deviceId } });
  if (!device) throw new AppError("Device not found", 404);

  const pairing = await prisma.pairingCode.findFirst({
    where: { deviceId: device.id, code, usedAt: null },
    orderBy: { createdAt: "desc" },
  });

  if (!pairing) throw new AppError("Invalid pairing code", 400);
  if (pairing.expiresAt < new Date()) throw new AppError("Pairing code expired", 400);

  await prisma.pairingCode.update({
    where: { id: pairing.id },
    data: { usedAt: new Date() },
  });

  return device;
}
