import { prisma } from "../utils/prisma";

export async function listSessionsForUser(technicianId: string) {
  return prisma.session.findMany({
    where: { technicianId },
    include: { device: true },
    orderBy: { requestedAt: "desc" },
    take: 100,
  });
}
