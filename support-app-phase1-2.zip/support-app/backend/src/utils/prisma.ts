import { PrismaClient } from "@prisma/client";

// Reuse a single PrismaClient instance across hot reloads in dev.
declare global {
  // eslint-disable-next-line no-var
  var __prisma__: PrismaClient | undefined;
}

export const prisma = global.__prisma__ || new PrismaClient();

if (env_is_dev()) {
  global.__prisma__ = prisma;
}

function env_is_dev() {
  return process.env.NODE_ENV !== "production";
}
