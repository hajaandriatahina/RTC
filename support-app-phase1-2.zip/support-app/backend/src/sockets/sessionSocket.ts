import { Server, Socket } from "socket.io";
import { prisma } from "../utils/prisma";
import { logger } from "../utils/logger";
import { onlineAgents } from "./deviceSocket";

/**
 * Phase 2: a technician requests a session against an online device. The
 * request is relayed to that device's Agent socket, which must explicitly
 * accept before anything else happens — no connection is ever established
 * without that step. Once accepted, both sockets join a private
 * `session:<id>` room and WebRTC offer/answer/ICE messages are relayed
 * through it; we never inspect or store SDP/ICE payloads, only pass them
 * through.
 */

interface SessionParticipants {
  deviceId: string; // human-readable deviceId (Device.deviceId)
  technicianSocketId: string;
  agentSocketId: string;
}

// sessionId -> participants, kept only while the session is pending/active.
export const activeSessions = new Map<string, SessionParticipants>();

function roomFor(sessionId: string) {
  return `session:${sessionId}`;
}

async function markSessionEnded(sessionId: string, reason: string) {
  await prisma.session
    .update({
      where: { id: sessionId },
      data: { status: "ENDED", endedAt: new Date(), endReason: reason },
    })
    .catch(() => {
      /* session may already be in a terminal state — ignore */
    });
}

export function registerSessionSocketHandlers(io: Server) {
  io.on("connection", (socket: Socket) => {
    // --- Technician requests a connection to a device -------------------
    socket.on("session:request", async ({ deviceId }: { deviceId: string }) => {
      if (!socket.data.userId) {
        return socket.emit("session:error", { message: "Authentification technicien requise" });
      }

      const device = await prisma.device.findUnique({ where: { deviceId } });
      if (!device) {
        return socket.emit("session:error", { message: "Appareil introuvable" });
      }

      const agentSocketId = onlineAgents.get(deviceId);
      if (!agentSocketId) {
        return socket.emit("session:error", { message: "Appareil hors ligne" });
      }

      const session = await prisma.session.create({
        data: {
          deviceId: device.id,
          technicianId: socket.data.userId,
          status: "PENDING",
        },
      });

      activeSessions.set(session.id, {
        deviceId,
        technicianSocketId: socket.id,
        agentSocketId,
      });

      io.to(agentSocketId).emit("session:incoming", {
        sessionId: session.id,
        deviceId,
        technicianEmail: socket.data.email || "Technicien",
      });

      socket.emit("session:pending", { sessionId: session.id });
      logger.info("Session requested", { sessionId: session.id, deviceId });
    });

    // --- Device owner (Agent) explicitly accepts or denies --------------
    socket.on(
      "session:respond",
      async ({ sessionId, accepted }: { sessionId: string; accepted: boolean }) => {
        const participants = activeSessions.get(sessionId);
        if (!participants || socket.id !== participants.agentSocketId) return;

        if (accepted) {
          await prisma.session.update({
            where: { id: sessionId },
            data: { status: "ACTIVE", acceptedAt: new Date() },
          });
          socket.join(roomFor(sessionId));
          io.sockets.sockets.get(participants.technicianSocketId)?.join(roomFor(sessionId));
        } else {
          await prisma.session.update({
            where: { id: sessionId },
            data: { status: "DENIED" },
          });
          activeSessions.delete(sessionId);
        }

        io.to(participants.technicianSocketId).emit("session:response", {
          sessionId,
          accepted,
        });
        logger.info("Session response", { sessionId, accepted });
      }
    );

    // --- WebRTC signaling relay (pass-through only) ----------------------
    socket.on("webrtc:offer", ({ sessionId, sdp }: { sessionId: string; sdp: unknown }) => {
      socket.to(roomFor(sessionId)).emit("webrtc:offer", { sessionId, sdp });
    });

    socket.on("webrtc:answer", ({ sessionId, sdp }: { sessionId: string; sdp: unknown }) => {
      socket.to(roomFor(sessionId)).emit("webrtc:answer", { sessionId, sdp });
    });

    socket.on(
      "webrtc:ice-candidate",
      ({ sessionId, candidate }: { sessionId: string; candidate: unknown }) => {
        socket.to(roomFor(sessionId)).emit("webrtc:ice-candidate", { sessionId, candidate });
      }
    );

    // Phase 4 placeholder: relayed as-is, the Agent decides whether to
    // honor it based on granted Android permissions.
    socket.on("control:request", ({ sessionId }: { sessionId: string }) => {
      socket.to(roomFor(sessionId)).emit("control:request", { sessionId });
    });

    // --- Explicit end (either side) --------------------------------------
    socket.on(
      "session:end",
      async ({ sessionId, reason }: { sessionId: string; reason?: string }) => {
        const participants = activeSessions.get(sessionId);
        await markSessionEnded(sessionId, reason || "unspecified");
        if (participants) {
          io.to(roomFor(sessionId)).emit("session:ended", { sessionId, reason: reason || "unspecified" });
          activeSessions.delete(sessionId);
        }
      }
    );

    // --- Cleanup on disconnect --------------------------------------------
    socket.on("disconnect", () => {
      for (const [sessionId, participants] of activeSessions.entries()) {
        if (
          participants.technicianSocketId === socket.id ||
          participants.agentSocketId === socket.id
        ) {
          io.to(roomFor(sessionId)).emit("session:ended", {
            sessionId,
            reason: "peer_disconnected",
          });
          markSessionEnded(sessionId, "peer_disconnected");
          activeSessions.delete(sessionId);
        }
      }
    });
  });
}
