import { Server } from "socket.io";
import { Server as HttpServer } from "http";
import { verifyAuthToken } from "../utils/jwt";
import { env } from "../config/env";
import { registerDeviceSocketHandlers } from "./deviceSocket";
import { registerSessionSocketHandlers } from "./sessionSocket";
import { logger } from "../utils/logger";

/**
 * WebSocket authentication: both the technician's dashboard tab and the
 * Android Agent connect here. The dashboard authenticates with the same JWT
 * used for HTTP. The Agent (Phase 3) will authenticate with a device-scoped
 * token; for Phase 1 we accept either a valid user JWT or an explicit
 * `role: "agent"` handshake so the device-status flow can be exercised
 * with a stub client before the real Android app exists.
 */
export function createSocketServer(httpServer: HttpServer): Server {
  const io = new Server(httpServer, {
    cors: {
      origin: env.clientOrigin,
      credentials: true,
    },
  });

  io.use((socket, next) => {
    const { token, role } = socket.handshake.auth as { token?: string; role?: string };

    if (role === "agent") {
      // Agents are authenticated via device pairing, not a user JWT.
      // Phase 3 will tighten this to a signed device token issued at
      // registration time.
      return next();
    }

    if (!token) {
      return next(new Error("Authentication token required"));
    }

    try {
      const payload = verifyAuthToken(token);
      socket.data.userId = payload.userId;
      socket.data.email = payload.email;
      next();
    } catch (err) {
      logger.warn("Socket auth rejected", { error: (err as Error).message });
      next(new Error("Invalid or expired token"));
    }
  });

  registerDeviceSocketHandlers(io);
  registerSessionSocketHandlers(io);

  return io;
}
