import { Server, Socket } from "socket.io";
import { setDeviceStatus } from "../services/device.service";
import { prisma } from "../utils/prisma";
import { logger } from "../utils/logger";

/**
 * Phase 1 scope: an Agent (or, for now, a stub client) connects, announces
 * its deviceId, and we flip it ONLINE. On disconnect we flip it OFFLINE.
 * WebRTC offer/answer/ICE relay is added in Phase 2 on top of this same
 * namespace/connection.
 */

interface AgentAnnouncePayload {
  deviceId: string;
}

// deviceId -> socket.id, so the web dashboard can later target a specific
// online agent for signaling (used starting Phase 2).
export const onlineAgents = new Map<string, string>();

export function registerDeviceSocketHandlers(io: Server) {
  io.on("connection", (socket: Socket) => {
    logger.info("Socket connected", { socketId: socket.id });

    socket.on("agent:announce", async (payload: AgentAnnouncePayload) => {
      try {
        const device = await prisma.device.findUnique({ where: { deviceId: payload.deviceId } });
        if (!device) {
          socket.emit("agent:error", { message: "Unknown deviceId" });
          return;
        }

        onlineAgents.set(payload.deviceId, socket.id);
        socket.data.deviceId = payload.deviceId;

        await setDeviceStatus(payload.deviceId, "ONLINE");
        io.emit("device:status", { deviceId: payload.deviceId, status: "ONLINE" });

        logger.info("Agent online", { deviceId: payload.deviceId, socketId: socket.id });
      } catch (err) {
        logger.error("agent:announce failed", { error: (err as Error).message });
        socket.emit("agent:error", { message: "Failed to register device as online" });
      }
    });

    socket.on("disconnect", async () => {
      const deviceId: string | undefined = socket.data.deviceId;
      if (deviceId) {
        onlineAgents.delete(deviceId);
        try {
          await setDeviceStatus(deviceId, "OFFLINE");
          io.emit("device:status", { deviceId, status: "OFFLINE" });
          logger.info("Agent offline", { deviceId });
        } catch (err) {
          logger.error("Failed to mark device offline", { deviceId, error: (err as Error).message });
        }
      }
      logger.info("Socket disconnected", { socketId: socket.id });
    });
  });
}
