import { Router } from "express";
import { requireAuth } from "../middleware/auth.middleware";
import {
  createDevice,
  listDevices,
  getDevice,
  requestPairingCode,
} from "../controllers/device.controller";

const router = Router();

router.use(requireAuth);

router.post("/", createDevice);
router.get("/", listDevices);
router.get("/:id", getDevice);
router.post("/:id/pairing-code", requestPairingCode);

export default router;
