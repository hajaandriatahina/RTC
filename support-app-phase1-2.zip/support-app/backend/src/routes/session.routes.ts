import { Router } from "express";
import { requireAuth } from "../middleware/auth.middleware";
import { listSessions } from "../controllers/session.controller";

const router = Router();

router.use(requireAuth);
router.get("/", listSessions);

export default router;
