# Remote Support — Phase 1 + Phase 2

Phase 1 : authentification, enregistrement des appareils, statut en ligne/
hors ligne en temps réel.
Phase 2 (nouveau) : demande de connexion → acceptation explicite côté
appareil → signaling WebRTC → écran distant en direct dans le navigateur,
avec un **simulateur d'agent** (`agent-simulator.html`) qui joue le rôle de
la future app Android le temps de tester, plus l'historique des sessions
en base (`/sessions`).

## 1. Prérequis

- Node.js ≥ 18
- PostgreSQL ≥ 14 (local ou distant)

## 2. Backend

```bash
cd backend
npm install
cp .env.example .env
# éditez .env : DATABASE_URL, JWT_SECRET au minimum

npx prisma migrate dev --name init
npm run dev
```

Le serveur démarre sur `http://localhost:4000`.
Vérification rapide : `curl http://localhost:4000/health`

## 3. Frontend

```bash
cd frontend
npm install
cp .env.example .env
npm run dev
```

Ouvrez `http://localhost:5173`.

## 4. Tester le flux complet (Phase 1 + Phase 2)

1. `/register` → créer un compte technicien.
2. `/devices` → "+ Nouvel appareil" → donnez un nom. Un `deviceId` du type
   `XJ3K-9QZP` est généré, l'appareil apparaît "Hors ligne". Copiez ce
   Device ID.
3. Ouvrez **dans un second onglet** `http://localhost:5173/agent-simulator.html`
   (page statique servie par Vite, indépendante du reste de l'app React —
   elle simule le futur Agent Android). Collez le Device ID → "S'annoncer
   en ligne". Le statut passe à "En ligne" en direct dans l'onglet
   technicien, sans recharger la page.
4. Dans l'onglet technicien, ouvrez la fiche de l'appareil (`Ouvrir`) →
   "Demander une connexion".
5. Dans l'onglet simulateur, une carte "Demande de connexion entrante"
   apparaît → cliquez **Accepter**. Le navigateur demande l'autorisation
   de partager l'écran (`getDisplayMedia`) — c'est le seul geste explicite
   qui déclenche le partage, exactement comme le fera l'Agent Android une
   fois les permissions système accordées.
6. Dans l'onglet technicien, l'écran partagé apparaît en direct dans le
   lecteur vidéo, avec la latence mesurée en direct. Les boutons
   `Disconnect`, `Full screen`, `Refresh` (relance ICE) sont actifs ;
   `Request control` envoie déjà l'événement au simulateur mais n'a pas
   d'effet avant la Phase 4.
7. `/sessions` liste désormais l'historique réel (demandée, acceptée,
   terminée, motif) depuis la base PostgreSQL.

Le code de vérification à 6 chiffres (étape optionnelle, `PairingCode`,
TTL via `PAIRING_CODE_TTL_SECONDS`) reste disponible sur la fiche appareil
comme couche de sécurité supplémentaire, indépendante de l'acceptation
explicite ci-dessus.

## 5. Erreurs fréquentes

| Erreur | Cause probable | Correction |
|---|---|---|
| `Missing required environment variable: DATABASE_URL` | `.env` backend absent/mal rempli | copier `.env.example` → `.env` et renseigner l'URL Postgres |
| `P1001: Can't reach database server` | Postgres non démarré ou mauvais host/port | vérifier que Postgres tourne, tester `psql` avec la même URL |
| Erreur CORS dans la console navigateur | `CLIENT_ORIGIN` backend ≠ URL réelle du frontend | aligner `CLIENT_ORIGIN` (backend) et `VITE_API_URL`/`VITE_SOCKET_URL` (frontend) |
| `401 Invalid or expired token` juste après login | horloge système désynchronisée, ou `JWT_SECRET` changé après émission du token | se reconnecter ; vérifier l'heure système |
| Le statut ne passe jamais "En ligne" | Le simulateur n'a pas correctement émis `agent:announce`, ou le `deviceId` ne correspond à aucun appareil enregistré | vérifier l'orthographe exacte du Device ID (majuscules incluses) |
| Écran noir côté technicien après acceptation | `getDisplayMedia` refusé/annulé dans le simulateur, ou pare-feu bloquant les candidats ICE (réseau restrictif sans TURN) | relancer, vérifier la console des deux onglets ; en réseau restrictif, un serveur TURN sera nécessaire en production |
| `session:error — Appareil hors ligne` | Le simulateur a été fermé/déconnecté entre l'annonce et la demande | rouvrir `agent-simulator.html` et se ré-annoncer avant de redemander une connexion |
| Erreur TypeScript sur `RTCPeerConnection`/`getDisplayMedia` | `lib` du `tsconfig.json` frontend n'inclut pas `DOM` | déjà inclus dans le tsconfig fourni ; si modifié, vérifier `"lib": ["ES2020", "DOM", "DOM.Iterable"]` |

## 6. Prochaines étapes

Une fois cette Phase 2 validée de votre côté, la Phase 3 remplace le
simulateur HTML par une vraie app Agent Android : capture d'écran via les
API Android (MediaProjection), demande de permission système, et
transmission WebRTC vers ce même backend de signaling — aucun changement
côté backend/frontend web ne devrait être nécessaire, seul un nouveau
client vient parler le même protocole de sockets.
